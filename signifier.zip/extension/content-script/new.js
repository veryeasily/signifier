var inject;

inject = function() {
  var Sign, Signifier;
  Signifier = (function() {

    function Signifier() {}

    Signifier.loc = window.location;

    Signifier.socket = io.connect('http://www.sgnfier.com:7000');

    Signifier.findTextNode = function(str, node) {
      var child, _i, _len, _ref;
      _ref = node.childNodes;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        child = _ref[_i];
        if ((child.textContent || "").indexOf(str) > -1) {
          if (child.nodeType === 3) {
            console.log(child);
            return [child, child.data.indexOf(str)];
          } else if (child.nodeType === 1) {
            console.log("dove a level deeper with findTextNode");
            this.findTextNode(str, child);
          }
        }
      }
    };

    Signifier.getNeighborhood = function() {
      this.socket.emit('chillinAt', {
        host: this.loc.hostname,
        path: this.loc.pathname
      });
      return this.socket.on('heresYourHood', function(links) {
        var observer;
        console.log("response from heresYourHood!");
        console.log(links);
        Signifier.queWorkingLinks(links);
        observer = new WebKitMutationObserver(function(mutations) {
          var mutation, reals, temp, _i, _len, _results;
          console.log(mutations);
          window.mutations = mutations;
          reals = (function() {
            var _i, _len, _results;
            _results = [];
            for (_i = 0, _len = mutations.length; _i < _len; _i++) {
              mutation = mutations[_i];
              if ((temp = $(mutation.target)).hasClass("siggg") !== true) {
                if (mutation.target.textContent != null) {
                  _results.push(mutation.target);
                } else {
                  continue;
                }
              } else {
                continue;
              }
            }
            return _results;
          })();
          _results = [];
          for (_i = 0, _len = reals.length; _i < _len; _i++) {
            mutation = reals[_i];
            if (mutation.textContent !== "") {
              _results.push(Signifier.queWorkingLinks(links, mutation));
            }
          }
          return _results;
        });
        return observer.observe(document.body, {
          childList: true,
          subtree: true
        });
      });
    };

    Signifier.queWorkingLinks = function(links, parent) {
      var a, link, _i, _len, _ref, _results;
      if (parent == null) parent = document.body;
      if ((links.rows != null) && Array.isArray(links.rows)) {
        _ref = links.rows;
        _results = [];
        for (_i = 0, _len = _ref.length; _i < _len; _i++) {
          a = _ref[_i];
          if (!(parent.textContent.indexOf(a.value.margin) !== -1)) continue;
          link = a.value;
          _results.push(Signifier.fillInSign(link, parent));
        }
        return _results;
      }
    };

    Signifier.elementIsSmallest = function(elt, arr) {
      var temp, _i, _len;
      for (_i = 0, _len = arr.length; _i < _len; _i++) {
        temp = arr[_i];
        if (temp !== elt) if (elt.contains(temp)) return false;
      }
      return true;
    };

    Signifier.fillInSign = function(link, parent) {
      var actual, possibles;
      if (parent == null) parent = document.body;
      console.log("this is the link ->");
      console.log(link);
      actual = (possibles = $(parent).find("" + link.tag + ":contains(" + link.margin + ")")).filter(function(ind) {
        return Signifier.elementIsSmallest(this, possibles) && $(this).hasClass("siggg") !== true;
      });
      console.log("this is the possibles");
      console.log(possibles);
      console.log("this is the actuals: ");
      console.log(actual);
      actual.each(function(ind) {
        var endInfo, range, startInfo, wrapper;
        startInfo = Signifier.findTextNode(link.startText || link.text, this);
        endInfo = Signifier.findTextNode(link.endText || link.text, this);
        range = document.createRange();
        console.log("here is our link info");
        console.log(startInfo);
        console.log(endInfo);
        range.setStart(startInfo[0], startInfo[1]);
        range.setEnd(endInfo[0], endInfo[1] + (link.endText || link.text).length);
        wrapper = document.createElement('a');
        wrapper.href = link.url;
        wrapper.target = '_blank';
        range.surroundContents(wrapper);
        $(wrapper).addClass('signifier').addClass('siggg');
        return $(this).addClass("siggg");
      });
      return actual;
    };

    Signifier.socket.on('whereYat', function() {
      return Signifier.getNeighborhood();
    });

    return Signifier;

  })();
  Sign = (function() {

    Sign.findContainingChild = function(parent, elt) {
      var child, _i, _len, _ref;
      _ref = parent.childNodes;
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        child = _ref[_i];
        if (child.contains(elt)) return child;
      }
    };

    Sign.getChildIndex = function(elt) {
      var e, k;
      e = elt;
      k = 0;
      while (e = e.previousSibling) {
        ++k;
      }
      return k;
    };

    Sign.getOffsetToNode = function(parent, elt) {
      var a, child, goddamn, offset;
      if (parent === elt) {
        console.log("returning without reducing");
        return 0;
      } else {
        goddamn = (function() {
          var _i, _len, _ref, _results;
          _ref = parent.childNodes;
          _results = [];
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            a = _ref[_i];
            _results.push(a);
          }
          return _results;
        })();
        child = Sign.findContainingChild(parent, elt);
        offset = _.foldl(goddamn.slice(0, Sign.getChildIndex(child)), (function(memo, node) {
          return memo + node.textContent.length;
        }), 0);
        if (elt.parentNode !== parent) {
          offset += Sign.getOffsetToNode(Sign.findContainingChild(parent, elt), elt);
        }
        console.log("offset being returned from @getOffsetToNode is: " + offset);
        return offset;
      }
    };

    Sign.socket = Signifier.socket;

    Sign.getMargin = function(range) {
      var endOffset, left, right, send, startOffset;
      console.log("range is =");
      console.log(range);
      startOffset = Sign.getOffsetToNode(range.commonAncestorContainer, range.startContainer) + range.startOffset;
      console.log("startOffset = " + startOffset);
      endOffset = Sign.getOffsetToNode(range.commonAncestorContainer, range.endContainer) + range.endOffset;
      console.log("endOffset = " + endOffset);
      left = Math.max(0, startOffset - 10);
      right = Math.min(range.commonAncestorContainer.textContent.length, endOffset + 10);
      console.log("here is the index of our margin");
      console.log([left, right]);
      console.log("here is range.commonAncestorContainer.textContent");
      console.log(range.commonAncestorContainer.textContent);
      console.log("here is our margin!");
      console.log((send = range.commonAncestorContainer.textContent.slice(left, right)));
      return send;
    };

    function Sign() {
      var end, endStr, parent, range, sel, start, startStr, thing, url, _ref, _ref2, _ref3;
      sel = document.getSelection();
      console.log("made it to the try");
      try {
        if (sel.type !== "Range") {
          alert("no selection!");
          return;
        }
        range = sel.getRangeAt(0);
        if ((parent = this.parent = range.commonAncestorContainer).nodeType === 3) {
          parent = this.parent = parent.parentElement;
        }
        if (range.startContainer.parentElement !== range.endContainer.parentElement) {
          alert("select something simpiler");
          return;
        }
        if ((range.startContainer.nodeType !== 3) || (range.endContainer.nodeType !== 3)) {
          alert("we only can select text to turn to links for right now");
          return;
        }
      } catch (error) {
        throw error;
      }
      url = prompt("give link url", "http://www.awebsite.com");
      console.log("made it past the try");
      _ref = range = sel.getRangeAt(0), start = _ref.startContainer, (_ref2 = _ref.startContainer, startStr = _ref2.textContent), end = _ref.endContainer, (_ref3 = _ref.endContainer, endStr = _ref3.textContent);
      this.toDB = {
        tag: parent.tagName,
        text: range.toString(),
        startText: range.toString(),
        endText: range.toString(),
        margin: Sign.getMargin(range),
        url: url,
        host: document.location.hostname,
        path: document.location.pathname
      };
      if (range.startContainer !== range.endContainer) {
        console.log("trying to slice each container");
        this.toDB.startText = startStr.slice(range.startOffset, startStr.length + 1);
        this.toDB.endText = endStr.slice(0, range.endOffset);
      }
      console.log("" + this.toDB.startText + " is startText, " + this.toDB.endText + " is endText");
      thing = document.createElement('a');
      thing.href = url;
      thing.target = '_blank';
      range.surroundContents(thing);
      $(thing).addClass("signifier").addClass("siggg");
      $(parent).addClass("siggg");
      Sign.socket.emit("heresASign", this.toDB);
    }

    return Sign;

  }).call(this);
  return chrome.extension.onRequest.addListener(function(request, sender, sendResponse) {
    var makeSign;
    makeSign = function() {
      var sign;
      return sign = new Sign();
    };
    if (request.greeting === "makeSign") return makeSign();
  });
};

$(function() {
  return inject();
});
