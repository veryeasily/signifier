
chrome.browserAction.onClicked.addListener(function(tab) {
  return chrome.tabs.sendRequest(tab.id, {
    greeting: "makeSign"
  }, function(response) {
    return console.log(response);
  });
});
