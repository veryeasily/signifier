var db, db_name, io, nano;

io = require('socket.io').listen(7000);

nano = require('nano')('http://127.0.0.1:5984');

db_name = "signifier";

db = nano.use(db_name);

io.sockets.on('connection', function(socket) {
  var Signifier;
  Signifier = (function() {

    Signifier.socket = socket;

    Signifier.scoutHood = function(imAt) {
      console.log("querying db with [host,path] = ");
      console.log([imAt.host, imAt.path]);
      return db.view('signifier', 'neighborhood', {
        key: [imAt.host, imAt.path]
      }, function(err, signs) {
        console.log(signs);
        return Signifier.socket.emit("heresYourHood", signs);
      });
    };

    Signifier.sendSigns = function(signs) {
      return Signifier.socket.emit("heresYourHood", signs);
    };

    Signifier.deleteAllDocs = function() {
      return db.view('signifier', 'deleter', {
        key: null
      }, function(data) {
        var i, _i, _len, _ref, _results;
        if (data.rows) {
          _ref = data.rows;
          _results = [];
          for (_i = 0, _len = _ref.length; _i < _len; _i++) {
            i = _ref[_i];
            if (i._id !== "_design/signifier") {
              _results.push(db.destroy(i._id, i._rev, function(err, body) {
                if (err === false) {
                  return console.log(body);
                } else {
                  return console.log(err);
                }
              }));
            }
          }
          return _results;
        }
      });
    };

    function Signifier() {}

    return Signifier;

  })();
  socket.emit('whereYat');
  socket.on('chillinAt', function(imAt) {
    return Signifier.scoutHood(imAt);
  });
  return socket.on("heresASign", function(sign) {
    return db.insert(sign, function(err, body, headers) {
      if (err === false) return console.log(headers, body);
    });
  });
});
