<link rel="stylesheet" type="text/css" href="https://raw.github.com/silenter/signifier/master/css/github.css" />

<table border="0" cellpadding="0" cellspacing="0" frame="void" width="100%">
<colgroup>
<col class="one" border="0">
<col class="two" border="0" align="right">
</colgroup>
<tr>
<th rowspan="9">
<h1>signifier</h1>

<p>Hyperlink markup for the web - 
<a href="http://www.iep.utm.edu/derrida/#SH3b">http://www.iep.utm.edu/derrida/#SH3b</a>
or maybe 
<a href="http://en.wikipedia.org/wiki/Indra%27s_Net#Huayan_school">http://en.wikipedia.org/wiki/Indra%27s_Net#Huayan_school</a>
</p>
</th>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
<tr>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
<tr>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
<tr>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
<tr>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
<tr>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
<tr>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
<tr>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
<tr>
<td>
<img src="https://github.com/silenter/signifier/raw/master/images/icon.png" width="84px" height="64px" align="right">
</td>
</tr>
</table>
